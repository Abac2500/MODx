<?php
/**
 * pdoPage English Lexicon Entries for pdoArchive
 *
 * @package pdotools
 * @subpackage lexicon
 * @language en
 */

$_lang['pdoarchive_month_01'] = 'January';
$_lang['pdoarchive_month_02'] = 'February';
$_lang['pdoarchive_month_03'] = 'March';
$_lang['pdoarchive_month_04'] = 'April';
$_lang['pdoarchive_month_05'] = 'May';
$_lang['pdoarchive_month_06'] = 'June';
$_lang['pdoarchive_month_07'] = 'July';
$_lang['pdoarchive_month_08'] = 'August';
$_lang['pdoarchive_month_09'] = 'September';
$_lang['pdoarchive_month_10'] = 'October';
$_lang['pdoarchive_month_11'] = 'November';
$_lang['pdoarchive_month_12'] = 'December';
